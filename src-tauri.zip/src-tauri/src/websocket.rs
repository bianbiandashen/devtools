use tauri::{AppHandle, Manager};
use tokio::net::TcpListener;
use tokio_tungstenite::accept_async;
use futures_util::{SinkExt, StreamExt};
use tokio::sync::broadcast;

pub async fn start_websocket_server(addr: &str, app_handle: AppHandle) {
    let addr = addr.to_owned();
    let (tx, _rx) = broadcast::channel(100); // 创建一个广播通道

    // 克隆 tx 并监听 Tauri 事件，将其数据发送到广播通道
    let app_handle_clone = app_handle.clone();
    let tx_clone = tx.clone();
    tokio::spawn(async move {
        app_handle_clone.listen_global("command-output", move |event| {
            println!("Event received: {:?}", event);
            if let Some(payload) = event.payload() {
                let _ = tx_clone.send(payload.to_string());
                println!("payload.to_string {}", payload.to_string());
            } else {
                println!("No payload in event");
            }
        });
    });

    // 启动 WebSocket 服务器
    let listener = TcpListener::bind(&addr).await.expect("Failed to bind");
    println!("WebSocket server running on {}", addr);

    while let Ok((stream, _)) = listener.accept().await {
        println!("Client connected");
        let tx = tx.clone();
        tokio::spawn(async move {
            let ws_stream = accept_async(stream).await.expect("Failed to accept");
            let (mut write, mut read) = ws_stream.split();

            // 从广播通道接收数据并通过 WebSocket 发送
            let mut rx = tx.subscribe();
            tokio::spawn(async move {
                while let Ok(message) = rx.recv().await {
                    write.send(tokio_tungstenite::tungstenite::Message::Text(message)).await.expect("Failed to send");
                }
            });

            // 处理从 WebSocket 接收到的消息（如果需要）
            while let Some(Ok(msg)) = read.next().await {
                // 这里可以处理从 WebSocket 接收到的消息
            }
        });
    }
}
