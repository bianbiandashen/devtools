use tauri::{AppHandle, Manager};
use std::process::{Command, Stdio};
use std::io::{self, BufRead, BufReader, Read, Write}; // 确保导入 Read trait
use std::fs::{self, File, copy};
use std::path::{Path, PathBuf};
use serde_json::{Value, json, Error};
use dirs::home_dir;
use tempfile::NamedTempFile;

fn get_config_path() -> PathBuf {
    let mut path = home_dir().expect("Failed to get home directory");
    path.push(".devtools");

    // 创建 .devtools 目录（如果不存在）
    if !path.exists() {
        fs::create_dir(&path).expect("Failed to create .devtools directory");
    }

    path.push("configs_directory.json");

    // 如果文件不存在，则创建并写入默认内容
    if !path.exists() {
        let mut file = File::create(&path).expect("Failed to create config file");
        file.write_all(b"[]").expect("Failed to write default content to config file");
    }

    path
}

// 生成临时文件并写入数组内容
#[tauri::command]
pub fn create_temp_file_with_list(data: Vec<Value>) -> Result<String, String> {
    // 创建临时文件
    let mut temp_file = NamedTempFile::new().map_err(|e| format!("Failed to create temp file: {}", e))?;

    // 将数组内容序列化为 JSON 字符串
    let json_data = serde_json::to_string(&data).map_err(|e| format!("Failed to serialize data: {}", e))?;

    // 将 JSON 字符串写入临时文件
    temp_file.write_all(json_data.as_bytes()).map_err(|e| format!("Failed to write to temp file: {}", e))?;

    // 获取临时文件的路径
    let temp_file_path = temp_file.into_temp_path();
    let temp_file_path_str = temp_file_path.to_str().ok_or("Failed to convert temp file path to string")?.to_string();

    // 复制临时文件到一个新的路径
    let new_path = temp_file_path.with_extension("json");
    copy(&temp_file_path, &new_path).map_err(|e| format!("Failed to copy temp file: {}", e))?;

    Ok(new_path.to_str().ok_or("Failed to convert new file path to string")?.to_string())
}

#[tauri::command]
pub fn read_temp_file(file_path: String) -> Result<Vec<Value>, String> {
    // 打开临时文件
    let mut file = File::open(&file_path).map_err(|e| format!("Failed to open temp file: {}", e))?;

    // 读取文件内容
    let mut file_content = String::new();
    file.read_to_string(&mut file_content).map_err(|e| format!("Failed to read temp file: {}", e))?;

    // 将文件内容解析为 JSON 数组
    let data: Vec<Value> = serde_json::from_str(&file_content).map_err(|e| format!("Failed to parse JSON: {}", e))?;

    Ok(data)
}

#[tauri::command]
pub fn read_package_json_files(path: String) -> Result<Vec<Value>, String> {
    fn find_package_json_content(dir: &Path, contents: &mut Vec<Value>) -> io::Result<()> {
        if dir.is_dir() {
            // 获取目录下的所有条目
            for entry in fs::read_dir(dir)? {
                let entry = entry?;
                let path = entry.path();

                // 检查是不是文件以及是不是名为 "package.json"
                if path.is_file() && path.file_name() == Some(std::ffi::OsStr::new("package.json")) {
                    // 读取文件并存储内容
                    let mut file_content = String::new();
                    fs::File::open(&path)?.read_to_string(&mut file_content)?;

                    let mut json: Value = serde_json::from_str(&file_content)?;
                    json["path"] = json!(dir);
                    contents.push(json);
                }

                // 如果是一个目录，则尝试在该目录下找到 "package.json"
                if path.is_dir() {
                    let package_json_path = path.join("package.json");
                    if package_json_path.exists() {
                        let mut file_content = String::new();
                        fs::File::open(&package_json_path)?.read_to_string(&mut file_content)?;
                        let mut json: Value = serde_json::from_str(&file_content)?;
                        json["path"] = json!(path);
                        contents.push(json);
                    }
                }
            }
        }
        Ok(())
    }

    let mut package_json_contents = Vec::new();
    let root_dir = Path::new(&path);

    // 开始迭代根目录下的项目并收集内容
    if let Err(error) = find_package_json_content(&root_dir, &mut package_json_contents) {
        return Err(error.to_string());
    }

    // 返回所有找到的 package.json 文件内容
    if !package_json_contents.is_empty() {
        Ok(package_json_contents)
    } else {
        Err("No package.json files found in the specified path.".to_string())
    }
}

#[tauri::command]
pub fn save_path_config(configs: String) -> Result<(), String> {

    println!("configs_json: {:?}", configs);

    // 将JSON字符串解析为Value
    let configs: Vec<Value> = serde_json::from_str(&configs)
        .map_err(|e| format!("Failed to parse JSON: {}", e))?;

    // 定义根目录下的configs_directory.json文件的路径
    let path = get_config_path();

    println!("get_config_path {:?}", path);

    println!("configs: {:?}", configs);

    // 读取现有的配置文件（如果存在）
    let mut existing_configs: Vec<Value> = match fs::read_to_string(&path) {
        Ok(content) => serde_json::from_str(&content)
            .map_err(|e| format!("Failed to parse existing JSON: {}", e))?,
        Err(_) => Vec::new(),
    };

    // 更新现有的配置或添加新的配置
    for new_config in configs {
        if let Some(name) = new_config.get("name").and_then(|n| n.as_str()) {
            // 查找是否有相同name的配置
            if let Some(index) = existing_configs.iter().position(|c| c.get("name").and_then(|n| n.as_str()) == Some(name)) {
                // 如果找到了，替换之
                existing_configs[index] = new_config;
            } else {
                // 如果没有找到，添加新的配置
                existing_configs.push(new_config);
            }
        }
    }

    // 将更新后的配置写回文件
    let mut file = File::create(&path)
        .map_err(|e| format!("Failed to create file: {}", e))?;

    let updated_json = serde_json::to_string_pretty(&existing_configs)
        .map_err(|e| format!("Failed to serialize JSON: {}", e))?;

    file.write_all(updated_json.as_bytes())
        .map_err(|e| format!("Failed to write to file: {}", e))?;

    Ok(())
}

#[tauri::command]
pub fn read_path_config_cache() -> Result<Vec<Value>, std::string::String> {
    println!("read_path_config_cache start");

    // 定义根目录下的configs_directory.json文件的路径
    let path = get_config_path();

    // 读取现有的配置文件（如果存在）
    let mut existing_configs: Vec<Value> = match fs::read_to_string(&path) {
        Ok(content) => serde_json::from_str(&content)
            .map_err(|e| format!("Failed to parse existing JSON: {}", e))?,
        Err(_) => Vec::new(),
    };

    println!("existing_configs: {:?}", existing_configs);

     // 返回所有找到的 package.json 文件内容
     if !existing_configs.is_empty() {
        println!("existing_configs is not empty");
        Ok(existing_configs)
    } else {
        Err("No cache files found in the specified path.".to_string())
    }
}

#[tauri::command]
pub fn clear_path_config_cache() -> Result<Vec<Value>, std::string::String>{
    println!("clear_path_config_cache start");

    // 定义根目录下的configs_directory.json文件的路径
    let path = get_config_path();

     // 将更新后的配置写回文件
    let mut file = File::create(&path)
     .map_err(|e| format!("Failed to create file: {}", e))?;

    let mut existing_configs = Vec::new();

    let updated_json = serde_json::to_string_pretty(&existing_configs)
        .map_err(|e| format!("Failed to serialize JSON: {}", e))?;

    file.write_all(updated_json.as_bytes())
        .map_err(|e| format!("Failed to write to file: {}", e))?;

    Ok(existing_configs)
}


#[tauri::command]
pub fn is_proxy_enabled() -> Result<bool, String> {
    // 使用系统命令 `networksetup` 来获取当前的代理设置
    let output = Command::new("networksetup")
        .args(&["-getwebproxy", "Wi-Fi"]) // 这里假设使用的是 Wi-Fi 网络服务
        .output();

    match output {
        Ok(output) => {
            // 将输出转换为字符串
            let output_str = String::from_utf8_lossy(&output.stdout);
            // 检查输出中是否包含 "Enabled: Yes"
            if output_str.contains("Enabled: Yes") {
                Ok(true)
            } else {
                Ok(false)
            }
        },
        Err(e) => Err(format!("Failed to execute networksetup command: {}", e)),
    }
}

#[tauri::command]
pub fn exec_spawn_command(app_handle: AppHandle, path: String, command: String) -> Result<String, String> {
    std::thread::spawn(move || {
        println!("Starting command execution...");
        println!("Path: {}", path);
        println!("Command: {}", command);

        let output = Command::new("sh")
            .arg("-c")
            .arg(&command)
            .current_dir(&path)
            .stdout(Stdio::piped())
            .spawn();

        match output {
            Ok(mut child) => {
                println!("Command started successfully. PID: {}", child.id());
                if let Some(stdout) = child.stdout.take() {
                    let reader = BufReader::new(stdout);
                    for line in reader.lines() {
                        match line {
                            Ok(line) => {
                                println!("Command output: {}", line);
                                app_handle.emit_all("command-output", Some(line)).unwrap();
                            }
                            Err(e) => {
                                println!("Error reading line from command output: {}", e);
                                app_handle.emit_all("command-output", Some(format!("Error reading line: {}", e))).unwrap();
                            }
                        }
                    }
                } else {
                    println!("Failed to capture stdout of the command.");
                }

                match child.wait_with_output() {
                    Ok(output) => {
                        if output.status.success() {
                            println!("Command completed successfully.");
                            app_handle.emit_all("command-complete", Some("Command execution complete".to_string())).unwrap();
                        } else {
                            let stderr = String::from_utf8_lossy(&output.stderr);
                            println!("Command failed with stderr: {}", stderr);
                            app_handle.emit_all("command-complete", Some(format!("Command failed: {}", stderr))).unwrap();
                        }
                    }
                    Err(e) => {
                        println!("Failed to wait for command output: {}", e);
                        app_handle.emit_all("command-complete", Some(format!("Failed to wait for command output: {}", e))).unwrap();
                    }
                }
            }
            Err(e) => {
                println!("Failed to start command: {}", e);
                app_handle.emit_all("command-complete", Some(format!("Failed to start command: {}", e))).unwrap();
            }
        }
    });

    Ok("Command started".into())
}
