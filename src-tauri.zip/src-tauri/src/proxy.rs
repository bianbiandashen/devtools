use std::process::Command;

#[tauri::command]
pub fn enable_proxy(host: &str, port: &str) {
    let command = format!(
        "networksetup -setwebproxy 'Wi-Fi' {} {} && networksetup -setsecurewebproxy 'Wi-Fi' {} {}",
        host, port, host, port
    );

    if let Ok(_) = Command::new("sh")
        .arg("-c")
        .arg(&command)
        .output()
    {
        println!("Proxy enabled successfully");
    } else {
        println!("Failed to enable proxy");
    }
}

#[tauri::command]
pub fn disable_proxy() {
    let command = "networksetup -setwebproxystate 'Wi-Fi' off && networksetup -setsecurewebproxystate 'Wi-Fi' off";

    if let Ok(_) = Command::new("sh")
        .arg("-c")
        .arg(command)
        .output()
    {
        println!("Proxy disabled successfully");
    } else {
        println!("Failed to disable proxy");
    }
}
